package com.example.janotei;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JanoteiApplicationTests {

	@Test
	void contextLoads() {
	}

}
