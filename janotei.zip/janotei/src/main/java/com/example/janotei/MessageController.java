package com.example.janotei;

import com.example.janotei.Message;
import com.example.janotei.MessageRepository;
import com.example.janotei.WhatsAppService;

import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/messages")
@CrossOrigin(origins = "*")
public class MessageController {

    private final MessageRepository repo;
    private final WhatsAppService waService;

    public MessageController(MessageRepository repo, WhatsAppService waService) {
        this.repo = repo;
        this.waService = waService;
    }

    @GetMapping
    public List<Message> getAll() {
        return repo.findAll();
    }

    @PostMapping
    public Message sendMessage(@RequestBody Message message) {
        // 1. Salva como sent
        message.setType("sent");
        Message saved = repo.save(message);

        // 2. Envia via API oficial do WhatsApp
        // ⚠️ "to" deve ser o número no formato internacional, ex: "5511999999999"
        String destinationNumber = "5512981765402"; 
        waService.sendWhatsAppMessage(destinationNumber, message.getContent());

        return saved;
    }

    @PostMapping("/receive")
    public Message receiveMessage(@RequestBody Message message) {
        message.setType("received");
        return repo.save(message);
    }
}