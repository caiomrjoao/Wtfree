package com.example.janotei;

import com.example.janotei.Message;
import com.example.janotei.MessageRepository;

import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;

import java.util.Map;

@RestController
@RequestMapping("/webhook")
@CrossOrigin(origins = "*")
public class WebhookController {

    private final MessageRepository repo;
    private final String VERIFY_TOKEN = "teste"; // mesmo que cadastrou no console Meta

    public WebhookController(MessageRepository repo) {
        this.repo = repo;
    }

    // 1. Verificação inicial do webhook (Meta → GET)
    @GetMapping
    public ResponseEntity<String> verifyWebhook(
        @RequestParam("hub.mode") String mode,
        @RequestParam("hub.verify_token") String token,
        @RequestParam("hub.challenge") String challenge
    ) {
        if ("subscribe".equals(mode) && VERIFY_TOKEN.equals(token)) {
            return ResponseEntity.ok(challenge);
        } else {
            return ResponseEntity.status(403).body("Erro de verificação");
        }
    }

    // 2. Recepção de mensagens (Meta → POST)
    @PostMapping
    public ResponseEntity<String> receiveMessage(@RequestBody Map<String, Object> body) {
        try {
            // Navegar no JSON recebido (simplificado)
            Map<String, Object> entry = ((java.util.List<Map<String, Object>>) body.get("entry")).get(0);
            Map<String, Object> change = ((java.util.List<Map<String, Object>>) entry.get("changes")).get(0);
            Map<String, Object> value = (Map<String, Object>) change.get("value");

            if (value.containsKey("messages")) {
                Map<String, Object> messageObj = ((java.util.List<Map<String, Object>>) value.get("messages")).get(0);
                String text = ((Map<String, String>) messageObj.get("text")).get("body");

                // salvar no banco como received
                Message msg = new Message();
                msg.setContent(text);
                msg.setType("received");
                repo.save(msg);
            }

            return ResponseEntity.ok("EVENT_RECEIVED");
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok("EVENT_RECEIVED"); // nunca responder erro ao Meta
        }
    }
}
