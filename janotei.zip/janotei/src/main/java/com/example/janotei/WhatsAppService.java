package com.example.janotei;

import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import java.util.Map;

@Service
public class WhatsAppService {
    private final String TOKEN = "EAATPdrXBF5wBPNpCAvthW3Q3reZCkneIZABFPr95yWhkLHujoJteYN1MrEbCTNrGAk6cKXip9wgP6toDZBvMInheYBLlOcsVYICDqhfNj1PjXZAa3IaDa4ZCiohQTeKTV837QFzEaGD1EqJNwn5WlRYDF6uItADJTyXrb4cP2Bde6D3uqaGxoKZBhpXLLZB8Dp23GCvBIAWAT2JIC8g4MtvjKKBZBqFcfp0BmsxBRhBoCDkvNscZD";
    private final String PHONE_NUMBER_ID = "15551676715"; // do Meta

    public void sendWhatsAppMessage(String to, String text) {
        String url = "https://graph.facebook.com/v17.0/" + PHONE_NUMBER_ID + "/messages";

        RestTemplate rest = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setBearerAuth(TOKEN);

        Map<String, Object> payload = Map.of(
            "messaging_product", "whatsapp",
            "to", to,
            "text", Map.of("body", text)
        );

        HttpEntity<Map<String, Object>> request = new HttpEntity<>(payload, headers);
        rest.postForEntity(url, request, String.class);
    }
}