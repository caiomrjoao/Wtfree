package com.example.janotei;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import lombok.Data;

@Entity
@Data
public class Message {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String type; // sent | received
    private String content;
    private LocalDateTime timestamp = LocalDateTime.now();
}
