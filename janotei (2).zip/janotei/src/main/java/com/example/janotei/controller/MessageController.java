package com.example.janotei.controller;

import com.example.janotei.model.Message;
import com.example.janotei.repository.MessageRepository;

import com.example.janotei.service.WhatsAppService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;


@RestController
@RequestMapping("/api/messages")
@CrossOrigin(origins = "http://localhost:9000")
public class MessageController {

    private final MessageRepository repo;
    private final WhatsAppService waService;

    public MessageController(MessageRepository repo, WhatsAppService waService) {
        this.repo = repo;
        this.waService = waService;
    }

    @GetMapping
    public List<Message> getAll() {
        return repo.findAll();
    }

    @PostMapping
    public ResponseEntity<?> sendMessage(@RequestBody Message message) {
        if (message.getContent() == null || message.getContent().trim().isEmpty()) {
            return ResponseEntity.badRequest().body("Conteúdo da mensagem é obrigatório");
        }

        // Persistir como "sent"
        message.setType("sent");
        Message saved = repo.save(message);

        // Tenta enviar para WhatsApp
        try {
            String destinationNumber = "5512981765402"; // Substitua pelo número real
            waService.sendWhatsAppMessage(destinationNumber, message.getContent());
        } catch (Exception e) {
            System.err.println("Falha ao enviar WhatsApp: " + e.getMessage());
            // opcional: incluir info de falha no response
        }

        return ResponseEntity.ok(saved);
    }

    @PostMapping("/receive")
    public Message receiveMessage(@RequestBody Message message) {
        message.setType("received");
        return repo.save(message);
    }
}