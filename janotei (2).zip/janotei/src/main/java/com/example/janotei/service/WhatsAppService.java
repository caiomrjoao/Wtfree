package com.example.janotei.service;

import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import java.util.Map;

@Service
public class WhatsAppService {
    private final String token;
    private final String phoneNumberId; // do Meta

    public WhatsAppService(
            @org.springframework.beans.factory.annotation.Value("${whatsapp.access.token}") String token,
            @org.springframework.beans.factory.annotation.Value("${whatsapp.phone.number.id}") String phoneNumberId
    ) {
        this.token = token;
        this.phoneNumberId = phoneNumberId;
    }

    public void sendWhatsAppMessage(String to, String text) {
        String url = "https://graph.facebook.com/v20.0/" + phoneNumberId + "/messages";

        RestTemplate rest = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setBearerAuth(token);

        Map<String, Object> payload = Map.of(
            "messaging_product", "whatsapp",
            "to", to,
            "type", "text",
            "text", Map.of("preview_url", false, "body", text)
        );

        HttpEntity<Map<String, Object>> request = new HttpEntity<>(payload, headers);
        rest.postForEntity(url, request, String.class);
    }
}